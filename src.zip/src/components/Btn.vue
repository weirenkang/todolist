||||input button 组件||||

<template>
  <div class="Btn">
      <input type="text" v-model="title" placeholder="代办事项">
      <button @click="add()">提交</button>
     
  </div>
</template>

<script>
import Bus from "../Bus"
export default {

    name:"Btn",
    data(){
        return {
            title:"",
            arr:JSON.parse(localStorage.getItem("goods"))||[]
        }
    },
    methods:{
        add(){
            var obj={title:this.title,flag:false,isshow:false,}
            this.arr.push(obj)
           // this.title=""
            localStorage.setItem("goods",JSON.stringify(this.arr))
            Bus.$emit("ad",this.arr)
        }
    }
}
</script>

<style>
input{
    width: 200px;
    outline: none;
}
.Btn{
    text-align: center;
}
span{
    text-align: center;
}
</style>
