<template>
  <div id="app">
    <Btn></Btn>
      <list></list>
      
  </div>
</template>

<script>
import Btn from './components/Btn'
import list from './components/list'

export default {
  components:{
  list,
  Btn
},
  data(){
    return {

    }
  }
}
</script>
<style>
 
</style>