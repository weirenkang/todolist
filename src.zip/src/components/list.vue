|||list组件|||
<template>
  <div class="list">
      <p class="p1" >未完成 </p>
    <ul>
          <li v-for="(item,key) in list" :key="key" v-show="!item.flag&&!item.qx">
              <input type="checkbox" v-model="item.flag" >
             <span>{{item.title}}</span> 
              <button @click="del(key,true)">x</button>
          </li>
      </ul >
      <p  class="p1">已完成</p>
      <ul >
          <li v-for="(item,key) in list" :key="key" v-show="item.flag">
              <input type="checkbox" v-model="item.flag">
             <span class="p18">{{item.title}}</span> 
              <button @click="del(key,true)">x</button>
          </li>
      </ul>
      
  </div>
</template>

<script>
import Bus from "../Bus"
export default {
    name:"List",
    data(){
        return {
       
            list:JSON.parse(localStorage.getItem("goods"))||[]
        }
    },
    mounted(){
        Bus.$on("ad",(res)=>{
            console.log(res)
            this.list=res
        })
    },
    methods:{
        del(key,blo){
            this.list[key].qx=blo
             localStorage.setItem("goods",JSON.stringify(this.list))
        },
       
    }
}
</script>

<style>
.p18{
text-align: center;
margin: 0 auto;
}
.p2{
    margin-left: 426px;
    font-size: 30px;
    color: purple;
}
ul{
    list-style: none;
    text-align: center;
}
li{
width: 100%;
display: flex;
justify-content: space-between;
align-items: center;
margin: 5px auto;
}
.p1{
    width: 100%;
    height: 50px;
    line-height: 50px;
    background: paleturquoise;
    margin-top:5px ;
        color: purple;
}
p {
    text-align: center;
}
span{
  margin: 0 auto;
}
</style>